import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrashAltComponent } from './trash-alt.component';

describe('TrashAltComponent', () => {
  let component: TrashAltComponent;
  let fixture: ComponentFixture<TrashAltComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrashAltComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrashAltComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
