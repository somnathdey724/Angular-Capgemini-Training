import { Component ,Input,Output,EventEmitter, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-trash-alt',
  templateUrl: './trash-alt.component.html',
  styleUrls: ['./trash-alt.component.css']
})
export class TrashAltComponent implements OnInit  {

  constructor(private productService:ProductService){}
  
  @Input() productId: number;
  errorMassage: string;
  message: string;
  @Output() productClicked: EventEmitter<string> = new EventEmitter<string>();
  
  ngOnInit() {
  }
  onClick():void{
    this.productService.removeProductDetails(this.productId).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMassage=errorMessage;
      }
    );
    this.productClicked.emit(`The productId ${this.productId} was deleted!`);
    window.location.reload();
  }
}
